/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable global-require */
/* eslint-disable import/no-unresolved */

const AWS = require('aws-sdk');

const axios = require('axios');

const aws4 = require('aws4');

const secretManager = new AWS.SecretsManager();

let onPremKeys = {
    ONPREM_API_KEY: '',
    ONPREM_API_SECRET: '',
    ONPREM_API_ENDPOINT: ''
};
  
const secretsReq = secretManager.getSecretValue({ SecretId: 'amplify/TutukanInsights/OnPremAccess' }, (err, data) => {
    if (err) {
        throw err;
    } else if ('SecretString' in data) {
        onPremKeys = JSON.parse(data.SecretString);
    } else {
        const buff = Buffer.from(data.SecretBinary, 'base64');
        onPremKeys = JSON.parse(buff.toString('ascii'));
    }
}).promise();

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async ({arguments: { name }}) => {
    await secretsReq;

    const url = new URL(`${onPremKeys.ONPREM_API_ENDPOINT}/index.cfm/campaign?name=${name}`);
    const urlOptions = {
        protocol: url.protocol,
        hostname: url.hostname,
        port: url.port,
        path: url.pathname + url.search,
        method: 'GET',
        service: 's3', // force addition of X-Amz-Content-Sha256
        region: 'sa-tutuka-01'
    };

    aws4.sign(urlOptions, {
      accessKeyId: onPremKeys.ONPREM_API_KEY,
      secretAccessKey: onPremKeys.ONPREM_API_SECRET
    });
    
    const {data} = await axios.get(url.toString(), {headers: urlOptions.headers});
    
    return data;
};
