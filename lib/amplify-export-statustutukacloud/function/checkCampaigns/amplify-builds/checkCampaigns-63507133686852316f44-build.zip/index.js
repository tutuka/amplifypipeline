/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable import/no-unresolved */

/* Amplify Params - DO NOT EDIT
	API_STATUSTUTUKACLOUD_CAMPAIGNSTABLE_ARN
	API_STATUSTUTUKACLOUD_CAMPAIGNSTABLE_NAME
	API_STATUSTUTUKACLOUD_CHECKITEMSTABLE_ARN
	API_STATUSTUTUKACLOUD_CHECKITEMSTABLE_NAME
	API_STATUSTUTUKACLOUD_CHECKSTABLE_ARN
	API_STATUSTUTUKACLOUD_CHECKSTABLE_NAME
	API_STATUSTUTUKACLOUD_GRAPHQLAPIENDPOINTOUTPUT
	API_STATUSTUTUKACLOUD_GRAPHQLAPIIDOUTPUT
	API_STATUSTUTUKACLOUD_REPORTSTABLE_ARN
	API_STATUSTUTUKACLOUD_REPORTSTABLE_NAME
	ENV
	FUNCTION_STATUSTUTUKACLOUDGETREPORTMETADATA_NAME
	REGION
Amplify Params - DO NOT EDIT */

const AWS = require('aws-sdk');
const template = require('lodash/template');
const { v4: uuid } = require('uuid');

const docClient = new AWS.DynamoDB.DocumentClient();
const lambda = new AWS.Lambda();

async function getCampaigns() {
  const { Items } = await docClient
    .scan({
      TableName: process.env.API_STATUSTUTUKACLOUD_CAMPAIGNSTABLE_NAME,
      FilterExpression: '#dltd <> :bTrue',
      ExpressionAttributeNames: {
        '#dltd': '_deleted'
      },
      ExpressionAttributeValues: {
        ':bTrue': true
      }
    })
    .promise();

  return Items;
}

async function getReports() {
  const { Items } = await docClient
    .scan({
      TableName: process.env.API_STATUSTUTUKACLOUD_REPORTSTABLE_NAME,
      FilterExpression: '#dltd <> :bTrue',
      ExpressionAttributeNames: {
        '#dltd': '_deleted'
      },
      ExpressionAttributeValues: {
        ':bTrue': true
      }
    })
    .promise();

  return Items;
}

async function createAndSaveCheck() {
  const id = uuid();
  const now = Date.now();
  const isoNow = new Date().toISOString();

  const check = {
    id,
    Type: 'CAMPAIGN',
    Date: now,
    _version: 0,
    _lastChangedAt: now,
    _deleted: false,
    createdAt: isoNow,
    updatedAt: isoNow
  };

  return docClient
    .put({
      TableName: process.env.API_STATUSTUTUKACLOUD_CHECKSTABLE_NAME,
      Item: check
    })
    .promise()
    .then(() =>
      docClient
        .get({
          TableName: process.env.API_STATUSTUTUKACLOUD_CHECKSTABLE_NAME,
          Key: { id }
        })
        .promise()
    )
    .then(({ Item }) => Item);
}

function createCheckItem(campaign, report, check) {
  const checkItemNow = Date.now();
  const isoNow = new Date().toISOString();

  return {
    id: uuid(),
    Url: '',
    HttpResultCode: '',
    BodyLength: 0,
    StartAt: checkItemNow,
    FinishAt: 0,
    LastModified: 0,
    checkItemsCampaignId: campaign.id,
    checkItemsReportId: report.id,
    checkItemsCheckId: check.id,
    createdAt: isoNow,
    updatedAt: isoNow,
    _version: 0,
    _deleted: false,
    _lastChangedAt: checkItemNow
  };
}

function getReportDate(report, dateArg) {
  const newDate = new Date(dateArg);

  if (report.StartDate === 'PREDATE') {
    newDate.setDate(newDate.getDate() - 1);
    return newDate;
  }

  if (report.StartDate === 'NEXTDATE') {
    newDate.setDate(newDate.getDate() + 1);
    return newDate;
  }

  return newDate;
}

/**
 * {campaignuuid}/{campaignname}_MarkOffFile_GMT_plus_{timezone}_00h00_{date}.csv
 * {campaignuuid}/Daily_Settlement_Report_ICA{campaigncardica}_({dateUnderscores}).xls
 * {campaignuuid}/{campaignname}_DailyAuthFailure_{date}.csv
 * {campaignuuid}/DailyForexReport_CAMID{campaignid}_({dateUnderscores}).xls
 * {campaignuuid}/{campaignname}DailySettlements{date}.csv
 */
function getReportUrl(campaign, report, dateArg) {
  const compiled = template(report.ReportNamePattern, { interpolate: /{([\s\S]+?)}/g });

  const reportDate = getReportDate(report, dateArg).toLocaleDateString('en-ZA', { timeZone: 'Africa/Johannesburg'});

  return compiled({
    campaignuuid: campaign.CampaignUUID,
    campaignid: campaign.CampaignID,
    campaignname: campaign.CampaignName.replace(/\s/g, ''),
    timezone: campaign.CampaignUTCOffset,
    campaigncardica: campaign.CampaignCardIca,
    date: reportDate.replace(/\//g, ''),
    dateUnderscores: reportDate.replace(/\//g, '_')
  });
}

async function saveCheckItem(checkItem) {
  const putParams = {
    TableName: process.env.API_STATUSTUTUKACLOUD_CHECKITEMSTABLE_NAME,
    Item: checkItem
  };
  await docClient
    .put(putParams, (err) => {
      if (err) {
        console.error(`Error saving check item: ${err}`);
      }
    })
    .promise();
}

async function checkReport(campaign, report, check, dateArg) {
  const checkItem = createCheckItem(campaign, report, check);
  const reportUrl = getReportUrl(campaign, report, dateArg);
  checkItem.Url = reportUrl;

  try {
    const response = await lambda.invoke({ FunctionName: process.env.FUNCTION_STATUSTUTUKACLOUDGETREPORTMETADATA_NAME, Payload: JSON.stringify({ arguments: { reportUrl } }) }).promise();

    const payload = JSON.parse(response.Payload);

    if (payload.LastModified === 0) {
      throw new Error('Report not found');
    }

    checkItem.BodyLength = payload.ContentLength || checkItem.BodyLength;
    checkItem.LastModified = payload.LastModified;

    checkItem.HttpResultCode = '200';
  } catch (e) {
    console.error(e);
    checkItem.HttpResultCode = '404';
  }

  checkItem.FinishAt = Date.now();

  return saveCheckItem(checkItem);
}

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async ({ date = Date.now() }) => {
  const campaigns = await getCampaigns();

  const reports = await getReports();
  const check = await createAndSaveCheck();

  const promises = [];

  campaigns.forEach((campaign) => {
    reports.forEach((report) => {
      try {
        promises.push(checkReport(campaign, report, check, date).catch(console.error));
      } catch (e) {
        console.error(e);
      }
    });
  });

  await Promise.all(promises);
};
