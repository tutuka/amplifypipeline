/* Amplify Params - DO NOT EDIT
	API_STATUSTUTUKACLOUD_CHECKURLRUNSTABLE_ARN
	API_STATUSTUTUKACLOUD_CHECKURLRUNSTABLE_NAME
	API_STATUSTUTUKACLOUD_GRAPHQLAPIENDPOINTOUTPUT
	API_STATUSTUTUKACLOUD_GRAPHQLAPIIDOUTPUT
	API_STATUSTUTUKACLOUD_QUOTARUNSTABLE_ARN
	API_STATUSTUTUKACLOUD_QUOTARUNSTABLE_NAME
	ENV
	REGION
Amplify Params - DO NOT EDIT */

/* eslint-disable global-require */
/* eslint-disable import/no-unresolved */
const AWS = require('aws-sdk');

const { URL } = require('url');

const urlAdapters = {
  'http:': require('http'),
  'https:': require('https')
};
const aws4 = require('aws4');
/* eslint-disable import/no-unresolved */
/* eslint-disable global-require */

AWS.config.update({
  region: process.env.REGION
});
const docClient = new AWS.DynamoDB.DocumentClient();
const secretManager = new AWS.SecretsManager();

const currencyFormatter = new Intl.NumberFormat('en-ZA', { style: 'currency', currency: 'ZAR' });

const { Client } = require('node-rest-client');

const client = new Client();
client.registerMethod(
  'zendeskTicketsAdd',
  'https://tutuka.zendesk.com/api/v2/tickets.json',
  'POST'
);

let onPremKeys = {
  ONPREM_API_KEY: '',
  ONPREM_API_SECRET: '',
  ONPREM_API_ENDPOINT: '',
  ZENDESK_AUTH_TOKEN: ''
};

secretManager.getSecretValue({ SecretId: 'amplify/TutukanInsights/OnPremAccess' }, (err, data) => {
  if (err) {
    throw err;
  } else if ('SecretString' in data) {
    onPremKeys = JSON.parse(data.SecretString);
  } else {
    const buff = Buffer.from(data.SecretBinary, 'base64');
    onPremKeys = JSON.parse(buff.toString('ascii'));
  }
});

const resolveUrlAdapter = (
  () => (requestUri) =>
    urlAdapters[new URL(requestUri).protocol]
)();

function processQuery(query, processor, failure, success) {
  docClient.query(query, (err, data) => {
    if (err) {
      console.log(`Failed to fetch records: ${JSON.stringify(err, null, 2)}`);
      failure(err);
    } else {
      try {
        data.Items.forEach(processor);
        success(null, 'Completed');
      } catch (fail) {
        console.log('Failure during list processing', fail);
        failure(fail);
      }
    }
  });
}

function lockItem(table, itemId, callback) {
  const params = {
    TableName: table,
    Key: {
      id: itemId
    },
    UpdateExpression:
      'set lockedUntil = :timeout, updatedAt = :nowIso, #lstChngd = :now, #vrsn = #vrsn + :increment',
    ConditionExpression: 'lockedUntil < :now',
    ExpressionAttributeNames: {
      '#lstChngd': '_lastChangedAt',
      '#vrsn': '_version'
    },
    ExpressionAttributeValues: {
      ':now': Date.now(),
      ':nowIso': new Date().toISOString(),
      ':increment': 1,
      ':timeout': Date.now() + 2 * 60 * 1000
    }
  };
  docClient.update(params, (err, data) => {
    if (err) {
      console.log(`Failed to lock${JSON.stringify(err, null, 2)}`);
      callback(err);
    } else {
      callback(null, data);
    }
  });
}

function completeUrlCheck(itemId, httpStatus, contentLength) {
  const params = {
    TableName: process.env.API_STATUSTUTUKACLOUD_CHECKURLRUNSTABLE_NAME,
    Key: {
      id: itemId
    },
    UpdateExpression:
      'set finishAt = :now, lockedUntil = :unlock, httpResultCode = :status, bodyLength = :length, updatedAt = :nowIso, #lstChngd = :now, #vrsn = #vrsn + :increment',
    ExpressionAttributeNames: {
      '#lstChngd': '_lastChangedAt',
      '#vrsn': '_version'
    },
    ExpressionAttributeValues: {
      ':now': Date.now(),
      ':nowIso': new Date().toISOString(),
      ':increment': 1,
      ':unlock': 0,
      ':status': httpStatus,
      ':length': contentLength
    }
  };
  docClient.update(params, (err) => {
    if (err) {
      console.log(`Failed to update${JSON.stringify(err, null, 2)}`);
    }
  });
}

function persistQuotaRunUpdate(item, httpStatusCode, bodyItem, zendeskTicketId) {
  const params = {
    TableName: process.env.API_STATUSTUTUKACLOUD_QUOTARUNSTABLE_NAME,
    Key: {
      id: item.id
    },
    UpdateExpression:
      'set finishAt = :now, lockedUntil = :unlock, httpResultCode = :status, responseBody = :body, zendeskTicketId = :zenDesk, updatedAt = :nowIso, #lstChngd = :now, #vrsn = #vrsn + :increment',
    ExpressionAttributeNames: {
      '#lstChngd': '_lastChangedAt',
      '#vrsn': '_version'
    },
    ExpressionAttributeValues: {
      ':now': Date.now(),
      ':nowIso': new Date().toISOString(),
      ':increment': 1,
      ':unlock': 0,
      ':body': bodyItem,
      ':status': httpStatusCode,
      ':zenDesk': zendeskTicketId
    }
  };
  docClient.update(params, (err) => {
    if (err) {
      console.log(`Failed to update${JSON.stringify(err, null, 2)}`);
    }
  });
}

function completeQuotaRun(item, httpStatusCode, bodyItem) {
  if (httpStatusCode === 200) {
    const body = JSON.parse(bodyItem);
    if (body.CurrentBalance < item.balanceLimit) {
      const clientId = item.apiEndpoint.split('/').slice(-2)[0];
      const b64basic = Buffer.from(onPremKeys.ZENDESK_AUTH_TOKEN).toString('base64');
      const args = {
        headers: {
          Authorization: `Basic ${b64basic}`,
          'Content-Type': 'application/json; charset=utf-8'
        }
      };
      args.data = {
        ticket: {
          comment: {
            html_body: `<p>The <a href="https://voucherengine.tutuka.com/index.cfm?FuseAction=clients.viewClient&clientID=${clientId}">client <code>${clientId}</code></a> has a balance of <strong># ${currencyFormatter.format(
              body.CurrentBalance
            )}</strong> while the threshold is <strong># ${currencyFormatter.format(
              item.balanceLimit
            )}</strong>.</p><p>Please perform top-up.</p>`
          },
          priority: 'normal',
          status: 'new',
          group_id: 360002890617,
          subject: `INSIGHTS: ClientID=${clientId} quota below limit`,
          via: {
            channel: 'cd-insights'
          },
          requester: { name: 'Tutukan Insights', email: 'zendeskapi.cloud@tutuka.com' }
        }
      };
      try {
        client.methods.zendeskTicketsAdd(args, (data) => {
          persistQuotaRunUpdate(item, httpStatusCode, bodyItem, data.ticket.id);
        });
      } catch (zErr) {
        persistQuotaRunUpdate(item, 551, JSON.stringify(zErr), 0);
      }
    } else {
      persistQuotaRunUpdate(item, httpStatusCode, bodyItem, 0);
    }
  } else {
    persistQuotaRunUpdate(item, httpStatusCode, bodyItem, 0);
  }
}

function validateUrl(item) {
  lockItem(process.env.API_STATUSTUTUKACLOUD_CHECKURLRUNSTABLE_NAME, item.id, (err) => {
    if (!err) {
      resolveUrlAdapter(item.fullUri).get(item.fullUri, (res) => {
        const { statusCode } = res;
        const contentLength =
          'content-length' in res.headers ? parseInt(res.headers['content-length'], 10) : -1;
        completeUrlCheck(item.id, statusCode, contentLength);
      });
    }
  });
}

function checkQuota(item) {
  lockItem(process.env.API_STATUSTUTUKACLOUD_QUOTARUNSTABLE_NAME, item.id, (err) => {
    if (!err) {
      const extendedUrl = new URL(onPremKeys.ONPREM_API_ENDPOINT + item.apiEndpoint);
      const urlOptions = {
        protocol: extendedUrl.protocol,
        hostname: extendedUrl.hostname,
        port: extendedUrl.port,
        path: extendedUrl.pathname,
        search: extendedUrl.search,
        method: 'GET',
        service: 's3', // force addition of X-Amz-Content-Sha256
        region: 'sa-tutuka-01'
      };
      aws4.sign(urlOptions, {
        accessKeyId: onPremKeys.ONPREM_API_KEY,
        secretAccessKey: onPremKeys.ONPREM_API_SECRET
      });
      const req = resolveUrlAdapter(extendedUrl.toString()).request(urlOptions, (res) => {
        let body = '';
        const { statusCode } = res;
        res.on('data', (chunk) => {
          body += chunk;
        });
        res.on('end', () => {
          completeQuotaRun(item, statusCode, body);
        });
      });
      req.on('error', (rErr) => {
        console.log(`Quota check failure: ${rErr.message}`);
        completeQuotaRun(item, 599, JSON.stringify(rErr));
      });
      req.end();
    }
  });
}

exports.handler = (event, context, callback) => {
  const urlsQuery = {
    TableName: process.env.API_STATUSTUTUKACLOUD_CHECKURLRUNSTABLE_NAME,
    IndexName: 'byFinishAndLock',
    KeyConditionExpression: 'finishAt = :finish and lockedUntil < :now',
    ExpressionAttributeValues: {
      ':finish': 0,
      ':now': Date.now()
    },
    Limit: 30
  };
  const quotaQuery = {
    TableName: process.env.API_STATUSTUTUKACLOUD_QUOTARUNSTABLE_NAME,
    IndexName: 'byFinishAndLock',
    KeyConditionExpression: 'finishAt = :finish and lockedUntil < :now',
    ExpressionAttributeValues: {
      ':finish': 0,
      ':now': Date.now()
    },
    Limit: 30
  };
  processQuery(urlsQuery, validateUrl, callback, () => {
    processQuery(quotaQuery, checkQuota, callback, callback);
  });
};
