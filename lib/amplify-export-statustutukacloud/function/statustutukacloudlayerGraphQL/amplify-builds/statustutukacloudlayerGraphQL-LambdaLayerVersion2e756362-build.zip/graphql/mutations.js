"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.updateSchedules = exports.updateReports = exports.updateQuotas = exports.updateQuotaRuns = exports.updateChecks = exports.updateCheckUrls = exports.updateCheckUrlRuns = exports.updateCheckItems = exports.updateCampaigns = exports.deleteSchedules = exports.deleteReports = exports.deleteQuotas = exports.deleteQuotaRuns = exports.deleteChecks = exports.deleteCheckUrls = exports.deleteCheckUrlRuns = exports.deleteCheckItems = exports.deleteCampaigns = exports.createSchedules = exports.createReports = exports.createQuotas = exports.createQuotaRuns = exports.createChecks = exports.createCheckUrls = exports.createCheckUrlRuns = exports.createCheckItems = exports.createCampaigns = void 0;

/* tslint:disable */

/* eslint-disable */
// this is an auto generated file. This will be overwritten
const createQuotaRuns =
/* GraphQL */
`
  mutation CreateQuotaRuns(
    $input: CreateQuotaRunsInput!
    $condition: ModelQuotaRunsConditionInput
  ) {
    createQuotaRuns(input: $input, condition: $condition) {
      id
      quotaID
      apiEndpoint
      balanceLimit
      httpResultCode
      responseBody
      zendeskTicketId
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.createQuotaRuns = createQuotaRuns;
const updateQuotaRuns =
/* GraphQL */
`
  mutation UpdateQuotaRuns(
    $input: UpdateQuotaRunsInput!
    $condition: ModelQuotaRunsConditionInput
  ) {
    updateQuotaRuns(input: $input, condition: $condition) {
      id
      quotaID
      apiEndpoint
      balanceLimit
      httpResultCode
      responseBody
      zendeskTicketId
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.updateQuotaRuns = updateQuotaRuns;
const deleteQuotaRuns =
/* GraphQL */
`
  mutation DeleteQuotaRuns(
    $input: DeleteQuotaRunsInput!
    $condition: ModelQuotaRunsConditionInput
  ) {
    deleteQuotaRuns(input: $input, condition: $condition) {
      id
      quotaID
      apiEndpoint
      balanceLimit
      httpResultCode
      responseBody
      zendeskTicketId
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.deleteQuotaRuns = deleteQuotaRuns;
const createQuotas =
/* GraphQL */
`
  mutation CreateQuotas(
    $input: CreateQuotasInput!
    $condition: ModelQuotasConditionInput
  ) {
    createQuotas(input: $input, condition: $condition) {
      id
      scheduleID
      clientId
      balanceLimit
      withQuotaRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.createQuotas = createQuotas;
const updateQuotas =
/* GraphQL */
`
  mutation UpdateQuotas(
    $input: UpdateQuotasInput!
    $condition: ModelQuotasConditionInput
  ) {
    updateQuotas(input: $input, condition: $condition) {
      id
      scheduleID
      clientId
      balanceLimit
      withQuotaRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.updateQuotas = updateQuotas;
const deleteQuotas =
/* GraphQL */
`
  mutation DeleteQuotas(
    $input: DeleteQuotasInput!
    $condition: ModelQuotasConditionInput
  ) {
    deleteQuotas(input: $input, condition: $condition) {
      id
      scheduleID
      clientId
      balanceLimit
      withQuotaRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.deleteQuotas = deleteQuotas;
const createCheckUrlRuns =
/* GraphQL */
`
  mutation CreateCheckUrlRuns(
    $input: CreateCheckUrlRunsInput!
    $condition: ModelCheckUrlRunsConditionInput
  ) {
    createCheckUrlRuns(input: $input, condition: $condition) {
      id
      checkUrlID
      fullUri
      httpResultCode
      bodyLength
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.createCheckUrlRuns = createCheckUrlRuns;
const updateCheckUrlRuns =
/* GraphQL */
`
  mutation UpdateCheckUrlRuns(
    $input: UpdateCheckUrlRunsInput!
    $condition: ModelCheckUrlRunsConditionInput
  ) {
    updateCheckUrlRuns(input: $input, condition: $condition) {
      id
      checkUrlID
      fullUri
      httpResultCode
      bodyLength
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.updateCheckUrlRuns = updateCheckUrlRuns;
const deleteCheckUrlRuns =
/* GraphQL */
`
  mutation DeleteCheckUrlRuns(
    $input: DeleteCheckUrlRunsInput!
    $condition: ModelCheckUrlRunsConditionInput
  ) {
    deleteCheckUrlRuns(input: $input, condition: $condition) {
      id
      checkUrlID
      fullUri
      httpResultCode
      bodyLength
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.deleteCheckUrlRuns = deleteCheckUrlRuns;
const createCheckUrls =
/* GraphQL */
`
  mutation CreateCheckUrls(
    $input: CreateCheckUrlsInput!
    $condition: ModelCheckUrlsConditionInput
  ) {
    createCheckUrls(input: $input, condition: $condition) {
      id
      scheduleID
      uri
      withCheckUrlRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.createCheckUrls = createCheckUrls;
const updateCheckUrls =
/* GraphQL */
`
  mutation UpdateCheckUrls(
    $input: UpdateCheckUrlsInput!
    $condition: ModelCheckUrlsConditionInput
  ) {
    updateCheckUrls(input: $input, condition: $condition) {
      id
      scheduleID
      uri
      withCheckUrlRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.updateCheckUrls = updateCheckUrls;
const deleteCheckUrls =
/* GraphQL */
`
  mutation DeleteCheckUrls(
    $input: DeleteCheckUrlsInput!
    $condition: ModelCheckUrlsConditionInput
  ) {
    deleteCheckUrls(input: $input, condition: $condition) {
      id
      scheduleID
      uri
      withCheckUrlRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.deleteCheckUrls = deleteCheckUrls;
const createSchedules =
/* GraphQL */
`
  mutation CreateSchedules(
    $input: CreateSchedulesInput!
    $condition: ModelSchedulesConditionInput
  ) {
    createSchedules(input: $input, condition: $condition) {
      id
      name
      frequency
      withQuotas {
        nextToken
        startedAt
      }
      withCheckUrls {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.createSchedules = createSchedules;
const updateSchedules =
/* GraphQL */
`
  mutation UpdateSchedules(
    $input: UpdateSchedulesInput!
    $condition: ModelSchedulesConditionInput
  ) {
    updateSchedules(input: $input, condition: $condition) {
      id
      name
      frequency
      withQuotas {
        nextToken
        startedAt
      }
      withCheckUrls {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.updateSchedules = updateSchedules;
const deleteSchedules =
/* GraphQL */
`
  mutation DeleteSchedules(
    $input: DeleteSchedulesInput!
    $condition: ModelSchedulesConditionInput
  ) {
    deleteSchedules(input: $input, condition: $condition) {
      id
      name
      frequency
      withQuotas {
        nextToken
        startedAt
      }
      withCheckUrls {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.deleteSchedules = deleteSchedules;
const createCampaigns =
/* GraphQL */
`
  mutation CreateCampaigns(
    $input: CreateCampaignsInput!
    $condition: ModelCampaignsConditionInput
  ) {
    createCampaigns(input: $input, condition: $condition) {
      CampaignID
      CampaignUUID
      CampaignName
      CampaignUTCOffset
      CampaignCardICA
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.createCampaigns = createCampaigns;
const updateCampaigns =
/* GraphQL */
`
  mutation UpdateCampaigns(
    $input: UpdateCampaignsInput!
    $condition: ModelCampaignsConditionInput
  ) {
    updateCampaigns(input: $input, condition: $condition) {
      CampaignID
      CampaignUUID
      CampaignName
      CampaignUTCOffset
      CampaignCardICA
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.updateCampaigns = updateCampaigns;
const deleteCampaigns =
/* GraphQL */
`
  mutation DeleteCampaigns(
    $input: DeleteCampaignsInput!
    $condition: ModelCampaignsConditionInput
  ) {
    deleteCampaigns(input: $input, condition: $condition) {
      CampaignID
      CampaignUUID
      CampaignName
      CampaignUTCOffset
      CampaignCardICA
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.deleteCampaigns = deleteCampaigns;
const createReports =
/* GraphQL */
`
  mutation CreateReports(
    $input: CreateReportsInput!
    $condition: ModelReportsConditionInput
  ) {
    createReports(input: $input, condition: $condition) {
      Name
      ReportNamePattern
      StartDate
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.createReports = createReports;
const updateReports =
/* GraphQL */
`
  mutation UpdateReports(
    $input: UpdateReportsInput!
    $condition: ModelReportsConditionInput
  ) {
    updateReports(input: $input, condition: $condition) {
      Name
      ReportNamePattern
      StartDate
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.updateReports = updateReports;
const deleteReports =
/* GraphQL */
`
  mutation DeleteReports(
    $input: DeleteReportsInput!
    $condition: ModelReportsConditionInput
  ) {
    deleteReports(input: $input, condition: $condition) {
      Name
      ReportNamePattern
      StartDate
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.deleteReports = deleteReports;
const createChecks =
/* GraphQL */
`
  mutation CreateChecks(
    $input: CreateChecksInput!
    $condition: ModelChecksConditionInput
  ) {
    createChecks(input: $input, condition: $condition) {
      id
      Type
      Date
      CheckItems {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.createChecks = createChecks;
const updateChecks =
/* GraphQL */
`
  mutation UpdateChecks(
    $input: UpdateChecksInput!
    $condition: ModelChecksConditionInput
  ) {
    updateChecks(input: $input, condition: $condition) {
      id
      Type
      Date
      CheckItems {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.updateChecks = updateChecks;
const deleteChecks =
/* GraphQL */
`
  mutation DeleteChecks(
    $input: DeleteChecksInput!
    $condition: ModelChecksConditionInput
  ) {
    deleteChecks(input: $input, condition: $condition) {
      id
      Type
      Date
      CheckItems {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.deleteChecks = deleteChecks;
const createCheckItems =
/* GraphQL */
`
  mutation CreateCheckItems(
    $input: CreateCheckItemsInput!
    $condition: ModelCheckItemsConditionInput
  ) {
    createCheckItems(input: $input, condition: $condition) {
      id
      Campaign {
        CampaignID
        CampaignUUID
        CampaignName
        CampaignUTCOffset
        CampaignCardICA
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Report {
        Name
        ReportNamePattern
        StartDate
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      checkItemsCheckId
      Check {
        id
        Type
        Date
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Url
      HttpResultCode
      BodyLength
      LastModified
      StartAt
      FinishAt
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      checkItemsCampaignId
      checkItemsReportId
    }
  }
`;
exports.createCheckItems = createCheckItems;
const updateCheckItems =
/* GraphQL */
`
  mutation UpdateCheckItems(
    $input: UpdateCheckItemsInput!
    $condition: ModelCheckItemsConditionInput
  ) {
    updateCheckItems(input: $input, condition: $condition) {
      id
      Campaign {
        CampaignID
        CampaignUUID
        CampaignName
        CampaignUTCOffset
        CampaignCardICA
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Report {
        Name
        ReportNamePattern
        StartDate
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      checkItemsCheckId
      Check {
        id
        Type
        Date
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Url
      HttpResultCode
      BodyLength
      LastModified
      StartAt
      FinishAt
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      checkItemsCampaignId
      checkItemsReportId
    }
  }
`;
exports.updateCheckItems = updateCheckItems;
const deleteCheckItems =
/* GraphQL */
`
  mutation DeleteCheckItems(
    $input: DeleteCheckItemsInput!
    $condition: ModelCheckItemsConditionInput
  ) {
    deleteCheckItems(input: $input, condition: $condition) {
      id
      Campaign {
        CampaignID
        CampaignUUID
        CampaignName
        CampaignUTCOffset
        CampaignCardICA
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Report {
        Name
        ReportNamePattern
        StartDate
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      checkItemsCheckId
      Check {
        id
        Type
        Date
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Url
      HttpResultCode
      BodyLength
      LastModified
      StartAt
      FinishAt
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      checkItemsCampaignId
      checkItemsReportId
    }
  }
`;
exports.deleteCheckItems = deleteCheckItems;