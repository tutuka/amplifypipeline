"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.onUpdateSchedules = exports.onUpdateReports = exports.onUpdateQuotas = exports.onUpdateQuotaRuns = exports.onUpdateChecks = exports.onUpdateCheckUrls = exports.onUpdateCheckUrlRuns = exports.onUpdateCheckItems = exports.onUpdateCampaigns = exports.onDeleteSchedules = exports.onDeleteReports = exports.onDeleteQuotas = exports.onDeleteQuotaRuns = exports.onDeleteChecks = exports.onDeleteCheckUrls = exports.onDeleteCheckUrlRuns = exports.onDeleteCheckItems = exports.onDeleteCampaigns = exports.onCreateSchedules = exports.onCreateReports = exports.onCreateQuotas = exports.onCreateQuotaRuns = exports.onCreateChecks = exports.onCreateCheckUrls = exports.onCreateCheckUrlRuns = exports.onCreateCheckItems = exports.onCreateCampaigns = void 0;

/* tslint:disable */

/* eslint-disable */
// this is an auto generated file. This will be overwritten
const onCreateQuotaRuns =
/* GraphQL */
`
  subscription OnCreateQuotaRuns {
    onCreateQuotaRuns {
      id
      quotaID
      apiEndpoint
      balanceLimit
      httpResultCode
      responseBody
      zendeskTicketId
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onCreateQuotaRuns = onCreateQuotaRuns;
const onUpdateQuotaRuns =
/* GraphQL */
`
  subscription OnUpdateQuotaRuns {
    onUpdateQuotaRuns {
      id
      quotaID
      apiEndpoint
      balanceLimit
      httpResultCode
      responseBody
      zendeskTicketId
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onUpdateQuotaRuns = onUpdateQuotaRuns;
const onDeleteQuotaRuns =
/* GraphQL */
`
  subscription OnDeleteQuotaRuns {
    onDeleteQuotaRuns {
      id
      quotaID
      apiEndpoint
      balanceLimit
      httpResultCode
      responseBody
      zendeskTicketId
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onDeleteQuotaRuns = onDeleteQuotaRuns;
const onCreateQuotas =
/* GraphQL */
`
  subscription OnCreateQuotas {
    onCreateQuotas {
      id
      scheduleID
      clientId
      balanceLimit
      withQuotaRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onCreateQuotas = onCreateQuotas;
const onUpdateQuotas =
/* GraphQL */
`
  subscription OnUpdateQuotas {
    onUpdateQuotas {
      id
      scheduleID
      clientId
      balanceLimit
      withQuotaRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onUpdateQuotas = onUpdateQuotas;
const onDeleteQuotas =
/* GraphQL */
`
  subscription OnDeleteQuotas {
    onDeleteQuotas {
      id
      scheduleID
      clientId
      balanceLimit
      withQuotaRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onDeleteQuotas = onDeleteQuotas;
const onCreateCheckUrlRuns =
/* GraphQL */
`
  subscription OnCreateCheckUrlRuns {
    onCreateCheckUrlRuns {
      id
      checkUrlID
      fullUri
      httpResultCode
      bodyLength
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onCreateCheckUrlRuns = onCreateCheckUrlRuns;
const onUpdateCheckUrlRuns =
/* GraphQL */
`
  subscription OnUpdateCheckUrlRuns {
    onUpdateCheckUrlRuns {
      id
      checkUrlID
      fullUri
      httpResultCode
      bodyLength
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onUpdateCheckUrlRuns = onUpdateCheckUrlRuns;
const onDeleteCheckUrlRuns =
/* GraphQL */
`
  subscription OnDeleteCheckUrlRuns {
    onDeleteCheckUrlRuns {
      id
      checkUrlID
      fullUri
      httpResultCode
      bodyLength
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onDeleteCheckUrlRuns = onDeleteCheckUrlRuns;
const onCreateCheckUrls =
/* GraphQL */
`
  subscription OnCreateCheckUrls {
    onCreateCheckUrls {
      id
      scheduleID
      uri
      withCheckUrlRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onCreateCheckUrls = onCreateCheckUrls;
const onUpdateCheckUrls =
/* GraphQL */
`
  subscription OnUpdateCheckUrls {
    onUpdateCheckUrls {
      id
      scheduleID
      uri
      withCheckUrlRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onUpdateCheckUrls = onUpdateCheckUrls;
const onDeleteCheckUrls =
/* GraphQL */
`
  subscription OnDeleteCheckUrls {
    onDeleteCheckUrls {
      id
      scheduleID
      uri
      withCheckUrlRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onDeleteCheckUrls = onDeleteCheckUrls;
const onCreateSchedules =
/* GraphQL */
`
  subscription OnCreateSchedules {
    onCreateSchedules {
      id
      name
      frequency
      withQuotas {
        nextToken
        startedAt
      }
      withCheckUrls {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onCreateSchedules = onCreateSchedules;
const onUpdateSchedules =
/* GraphQL */
`
  subscription OnUpdateSchedules {
    onUpdateSchedules {
      id
      name
      frequency
      withQuotas {
        nextToken
        startedAt
      }
      withCheckUrls {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onUpdateSchedules = onUpdateSchedules;
const onDeleteSchedules =
/* GraphQL */
`
  subscription OnDeleteSchedules {
    onDeleteSchedules {
      id
      name
      frequency
      withQuotas {
        nextToken
        startedAt
      }
      withCheckUrls {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onDeleteSchedules = onDeleteSchedules;
const onCreateCampaigns =
/* GraphQL */
`
  subscription OnCreateCampaigns {
    onCreateCampaigns {
      CampaignID
      CampaignUUID
      CampaignName
      CampaignUTCOffset
      CampaignCardICA
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onCreateCampaigns = onCreateCampaigns;
const onUpdateCampaigns =
/* GraphQL */
`
  subscription OnUpdateCampaigns {
    onUpdateCampaigns {
      CampaignID
      CampaignUUID
      CampaignName
      CampaignUTCOffset
      CampaignCardICA
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onUpdateCampaigns = onUpdateCampaigns;
const onDeleteCampaigns =
/* GraphQL */
`
  subscription OnDeleteCampaigns {
    onDeleteCampaigns {
      CampaignID
      CampaignUUID
      CampaignName
      CampaignUTCOffset
      CampaignCardICA
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onDeleteCampaigns = onDeleteCampaigns;
const onCreateReports =
/* GraphQL */
`
  subscription OnCreateReports {
    onCreateReports {
      Name
      ReportNamePattern
      StartDate
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onCreateReports = onCreateReports;
const onUpdateReports =
/* GraphQL */
`
  subscription OnUpdateReports {
    onUpdateReports {
      Name
      ReportNamePattern
      StartDate
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onUpdateReports = onUpdateReports;
const onDeleteReports =
/* GraphQL */
`
  subscription OnDeleteReports {
    onDeleteReports {
      Name
      ReportNamePattern
      StartDate
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onDeleteReports = onDeleteReports;
const onCreateChecks =
/* GraphQL */
`
  subscription OnCreateChecks {
    onCreateChecks {
      id
      Type
      Date
      CheckItems {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onCreateChecks = onCreateChecks;
const onUpdateChecks =
/* GraphQL */
`
  subscription OnUpdateChecks {
    onUpdateChecks {
      id
      Type
      Date
      CheckItems {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onUpdateChecks = onUpdateChecks;
const onDeleteChecks =
/* GraphQL */
`
  subscription OnDeleteChecks {
    onDeleteChecks {
      id
      Type
      Date
      CheckItems {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.onDeleteChecks = onDeleteChecks;
const onCreateCheckItems =
/* GraphQL */
`
  subscription OnCreateCheckItems {
    onCreateCheckItems {
      id
      Campaign {
        CampaignID
        CampaignUUID
        CampaignName
        CampaignUTCOffset
        CampaignCardICA
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Report {
        Name
        ReportNamePattern
        StartDate
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      checkItemsCheckId
      Check {
        id
        Type
        Date
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Url
      HttpResultCode
      BodyLength
      LastModified
      StartAt
      FinishAt
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      checkItemsCampaignId
      checkItemsReportId
    }
  }
`;
exports.onCreateCheckItems = onCreateCheckItems;
const onUpdateCheckItems =
/* GraphQL */
`
  subscription OnUpdateCheckItems {
    onUpdateCheckItems {
      id
      Campaign {
        CampaignID
        CampaignUUID
        CampaignName
        CampaignUTCOffset
        CampaignCardICA
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Report {
        Name
        ReportNamePattern
        StartDate
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      checkItemsCheckId
      Check {
        id
        Type
        Date
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Url
      HttpResultCode
      BodyLength
      LastModified
      StartAt
      FinishAt
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      checkItemsCampaignId
      checkItemsReportId
    }
  }
`;
exports.onUpdateCheckItems = onUpdateCheckItems;
const onDeleteCheckItems =
/* GraphQL */
`
  subscription OnDeleteCheckItems {
    onDeleteCheckItems {
      id
      Campaign {
        CampaignID
        CampaignUUID
        CampaignName
        CampaignUTCOffset
        CampaignCardICA
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Report {
        Name
        ReportNamePattern
        StartDate
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      checkItemsCheckId
      Check {
        id
        Type
        Date
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Url
      HttpResultCode
      BodyLength
      LastModified
      StartAt
      FinishAt
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      checkItemsCampaignId
      checkItemsReportId
    }
  }
`;
exports.onDeleteCheckItems = onDeleteCheckItems;