"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.syncSchedules = exports.syncReports = exports.syncQuotas = exports.syncQuotaRuns = exports.syncChecks = exports.syncCheckUrls = exports.syncCheckUrlRuns = exports.syncCheckItems = exports.syncCampaigns = exports.listSchedules = exports.listReports = exports.listQuotas = exports.listQuotaRuns = exports.listChecks = exports.listCheckUrls = exports.listCheckUrlRuns = exports.listCheckItems = exports.listCampaigns = exports.getSchedules = exports.getReports = exports.getReportMetaData = exports.getQuotas = exports.getQuotaRuns = exports.getChecks = exports.getCheckUrls = exports.getCheckUrlRuns = exports.getCheckItems = exports.getCampaignsByName = exports.getCampaigns = void 0;

/* tslint:disable */

/* eslint-disable */
// this is an auto generated file. This will be overwritten
const getReportMetaData =
/* GraphQL */
`
  query GetReportMetaData($reportUrl: String!) {
    getReportMetaData(reportUrl: $reportUrl) {
      LastModified
      ContentLength
      ContentType
    }
  }
`;
exports.getReportMetaData = getReportMetaData;
const getCampaignsByName =
/* GraphQL */
`
  query GetCampaignsByName($name: String!) {
    getCampaignsByName(name: $name) {
      CampaignID
      CampaignUUID
      CampaignName
      CampaignUTCOffset
      CampaignCardICA
    }
  }
`;
exports.getCampaignsByName = getCampaignsByName;
const getQuotaRuns =
/* GraphQL */
`
  query GetQuotaRuns($id: ID!) {
    getQuotaRuns(id: $id) {
      id
      quotaID
      apiEndpoint
      balanceLimit
      httpResultCode
      responseBody
      zendeskTicketId
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.getQuotaRuns = getQuotaRuns;
const listQuotaRuns =
/* GraphQL */
`
  query ListQuotaRuns(
    $filter: ModelQuotaRunsFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listQuotaRuns(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        quotaID
        apiEndpoint
        balanceLimit
        httpResultCode
        responseBody
        zendeskTicketId
        startAt
        finishAt
        lockedUntil
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.listQuotaRuns = listQuotaRuns;
const syncQuotaRuns =
/* GraphQL */
`
  query SyncQuotaRuns(
    $filter: ModelQuotaRunsFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncQuotaRuns(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        quotaID
        apiEndpoint
        balanceLimit
        httpResultCode
        responseBody
        zendeskTicketId
        startAt
        finishAt
        lockedUntil
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.syncQuotaRuns = syncQuotaRuns;
const getQuotas =
/* GraphQL */
`
  query GetQuotas($id: ID!) {
    getQuotas(id: $id) {
      id
      scheduleID
      clientId
      balanceLimit
      withQuotaRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.getQuotas = getQuotas;
const listQuotas =
/* GraphQL */
`
  query ListQuotas(
    $filter: ModelQuotasFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listQuotas(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        scheduleID
        clientId
        balanceLimit
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.listQuotas = listQuotas;
const syncQuotas =
/* GraphQL */
`
  query SyncQuotas(
    $filter: ModelQuotasFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncQuotas(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        scheduleID
        clientId
        balanceLimit
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.syncQuotas = syncQuotas;
const getCheckUrlRuns =
/* GraphQL */
`
  query GetCheckUrlRuns($id: ID!) {
    getCheckUrlRuns(id: $id) {
      id
      checkUrlID
      fullUri
      httpResultCode
      bodyLength
      startAt
      finishAt
      lockedUntil
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.getCheckUrlRuns = getCheckUrlRuns;
const listCheckUrlRuns =
/* GraphQL */
`
  query ListCheckUrlRuns(
    $filter: ModelCheckUrlRunsFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listCheckUrlRuns(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        checkUrlID
        fullUri
        httpResultCode
        bodyLength
        startAt
        finishAt
        lockedUntil
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.listCheckUrlRuns = listCheckUrlRuns;
const syncCheckUrlRuns =
/* GraphQL */
`
  query SyncCheckUrlRuns(
    $filter: ModelCheckUrlRunsFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncCheckUrlRuns(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        checkUrlID
        fullUri
        httpResultCode
        bodyLength
        startAt
        finishAt
        lockedUntil
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.syncCheckUrlRuns = syncCheckUrlRuns;
const getCheckUrls =
/* GraphQL */
`
  query GetCheckUrls($id: ID!) {
    getCheckUrls(id: $id) {
      id
      scheduleID
      uri
      withCheckUrlRuns {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.getCheckUrls = getCheckUrls;
const listCheckUrls =
/* GraphQL */
`
  query ListCheckUrls(
    $filter: ModelCheckUrlsFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listCheckUrls(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        scheduleID
        uri
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.listCheckUrls = listCheckUrls;
const syncCheckUrls =
/* GraphQL */
`
  query SyncCheckUrls(
    $filter: ModelCheckUrlsFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncCheckUrls(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        scheduleID
        uri
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.syncCheckUrls = syncCheckUrls;
const getSchedules =
/* GraphQL */
`
  query GetSchedules($id: ID!) {
    getSchedules(id: $id) {
      id
      name
      frequency
      withQuotas {
        nextToken
        startedAt
      }
      withCheckUrls {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.getSchedules = getSchedules;
const listSchedules =
/* GraphQL */
`
  query ListSchedules(
    $filter: ModelSchedulesFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listSchedules(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        name
        frequency
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.listSchedules = listSchedules;
const syncSchedules =
/* GraphQL */
`
  query SyncSchedules(
    $filter: ModelSchedulesFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncSchedules(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        name
        frequency
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.syncSchedules = syncSchedules;
const getCampaigns =
/* GraphQL */
`
  query GetCampaigns($id: ID!) {
    getCampaigns(id: $id) {
      CampaignID
      CampaignUUID
      CampaignName
      CampaignUTCOffset
      CampaignCardICA
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.getCampaigns = getCampaigns;
const listCampaigns =
/* GraphQL */
`
  query ListCampaigns(
    $filter: ModelCampaignsFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listCampaigns(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        CampaignID
        CampaignUUID
        CampaignName
        CampaignUTCOffset
        CampaignCardICA
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.listCampaigns = listCampaigns;
const syncCampaigns =
/* GraphQL */
`
  query SyncCampaigns(
    $filter: ModelCampaignsFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncCampaigns(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        CampaignID
        CampaignUUID
        CampaignName
        CampaignUTCOffset
        CampaignCardICA
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.syncCampaigns = syncCampaigns;
const getReports =
/* GraphQL */
`
  query GetReports($id: ID!) {
    getReports(id: $id) {
      Name
      ReportNamePattern
      StartDate
      id
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.getReports = getReports;
const listReports =
/* GraphQL */
`
  query ListReports(
    $filter: ModelReportsFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listReports(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        Name
        ReportNamePattern
        StartDate
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.listReports = listReports;
const syncReports =
/* GraphQL */
`
  query SyncReports(
    $filter: ModelReportsFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncReports(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        Name
        ReportNamePattern
        StartDate
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.syncReports = syncReports;
const getChecks =
/* GraphQL */
`
  query GetChecks($id: ID!) {
    getChecks(id: $id) {
      id
      Type
      Date
      CheckItems {
        nextToken
        startedAt
      }
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
exports.getChecks = getChecks;
const listChecks =
/* GraphQL */
`
  query ListChecks(
    $filter: ModelChecksFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listChecks(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        Type
        Date
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.listChecks = listChecks;
const syncChecks =
/* GraphQL */
`
  query SyncChecks(
    $filter: ModelChecksFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncChecks(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        Type
        Date
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
exports.syncChecks = syncChecks;
const getCheckItems =
/* GraphQL */
`
  query GetCheckItems($id: ID!) {
    getCheckItems(id: $id) {
      id
      Campaign {
        CampaignID
        CampaignUUID
        CampaignName
        CampaignUTCOffset
        CampaignCardICA
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Report {
        Name
        ReportNamePattern
        StartDate
        id
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      checkItemsCheckId
      Check {
        id
        Type
        Date
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      Url
      HttpResultCode
      BodyLength
      LastModified
      StartAt
      FinishAt
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      checkItemsCampaignId
      checkItemsReportId
    }
  }
`;
exports.getCheckItems = getCheckItems;
const listCheckItems =
/* GraphQL */
`
  query ListCheckItems(
    $filter: ModelCheckItemsFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listCheckItems(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        checkItemsCheckId
        Url
        HttpResultCode
        BodyLength
        LastModified
        StartAt
        FinishAt
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
        checkItemsCampaignId
        checkItemsReportId
      }
      nextToken
      startedAt
    }
  }
`;
exports.listCheckItems = listCheckItems;
const syncCheckItems =
/* GraphQL */
`
  query SyncCheckItems(
    $filter: ModelCheckItemsFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncCheckItems(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        checkItemsCheckId
        Url
        HttpResultCode
        BodyLength
        LastModified
        StartAt
        FinishAt
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
        checkItemsCampaignId
        checkItemsReportId
      }
      nextToken
      startedAt
    }
  }
`;
exports.syncCheckItems = syncCheckItems;