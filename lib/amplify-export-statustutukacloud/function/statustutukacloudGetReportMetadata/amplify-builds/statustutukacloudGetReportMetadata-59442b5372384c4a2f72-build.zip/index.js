const AWS = require('aws-sdk');

const s3 = new AWS.S3();

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async (args) => s3
    .headObject({
      Bucket: process.env.S3_BUCKET_REPORTS,
      Key: `WebShare/VoucherEngine/downloads/${args?.arguments?.reportUrl}`
    })
    .promise()
    .then((res) => ({
      LastModified: new Date(res.LastModified).getTime(),
      ContentLength: res.ContentLength,
      ContentType: res.ContentType
    }))
    .catch(() => ({
      LastModified: 0,
      ContentLength: 0,
      ContentType: ""
    }))
