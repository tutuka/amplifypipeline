/* Amplify Params - DO NOT EDIT
	API_STATUSTUTUKACLOUD_CHECKURLRUNSTABLE_ARN
	API_STATUSTUTUKACLOUD_CHECKURLRUNSTABLE_NAME
	API_STATUSTUTUKACLOUD_CHECKURLSTABLE_ARN
	API_STATUSTUTUKACLOUD_CHECKURLSTABLE_NAME
	API_STATUSTUTUKACLOUD_GRAPHQLAPIENDPOINTOUTPUT
	API_STATUSTUTUKACLOUD_GRAPHQLAPIIDOUTPUT
	API_STATUSTUTUKACLOUD_QUOTARUNSTABLE_ARN
	API_STATUSTUTUKACLOUD_QUOTARUNSTABLE_NAME
	API_STATUSTUTUKACLOUD_QUOTASTABLE_ARN
	API_STATUSTUTUKACLOUD_QUOTASTABLE_NAME
	API_STATUSTUTUKACLOUD_SCHEDULESTABLE_ARN
	API_STATUSTUTUKACLOUD_SCHEDULESTABLE_NAME
	ENV
	REGION
Amplify Params - DO NOT EDIT */

/* eslint-disable global-require */
/* eslint-disable import/no-unresolved */
/* eslint-disable import/no-extraneous-dependencies */
const AWS = require('aws-sdk');

const { v4: uuidv4 } = require('uuid');

const docClient = new AWS.DynamoDB.DocumentClient();
const cronParser = require('cron-parser');
/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable import/no-unresolved */
/* eslint-disable global-require */

AWS.config.update({
  region: process.env.REGION
});

const groupParams = {
  TableName: process.env.API_STATUSTUTUKACLOUD_SCHEDULESTABLE_NAME,
  FilterExpression: '#dltd <> :bTrue',
  ExpressionAttributeNames: {
    '#dltd': '_deleted'
  },
  ExpressionAttributeValues: {
    ':bTrue': true
  }
};
const groupStartTime = Date.now();
const groupStartTimeIso = new Date(groupStartTime).toISOString();
const queryWindow = [groupStartTime - 10 * 60 * 1000, groupStartTime + 10 * 60 * 1000];

function variableGenerate(variable) {
  const elements = variable.split('%', 2);
  // adjust date offset
  const newDate = new Date();
  switch (elements[0]) {
    case 'yesterday':
      newDate.setDate(newDate.getDate() - 1);
      break;
    default:
      break;
  }
  // create format replacers
  const replacementPairs = {
    YYYY: newDate.getFullYear(),
    YY: newDate.getFullYear().toString().slice(-2),
    MM: (newDate.getMonth() + 1).toString().padStart(2, 0),
    DD: newDate.getDate().toString().padStart(2, 0)
  };
  // pull formatting input
  let formatted = 'YYYYMMDD';
  if (elements[1]) {
    [, formatted] = elements;
  }
  // inject values
  Object.keys(replacementPairs).forEach((key) => {
    formatted = formatted.replace(key, replacementPairs[key]);
  });
  return formatted;
}

function replaceVariables(url) {
  const symbols = url.split('');
  let inflected = '';
  let state = 0;
  let modifiable = '';
  symbols.forEach((char) => {
    if (state === 1) {
      if (char === '}') {
        state = 0;
        inflected += variableGenerate(modifiable);
        modifiable = '';
      } else {
        modifiable += char;
      }
    } else if (char === '{') {
      state = 1;
    } else {
      inflected += char;
    }
  });
  return inflected;
}

function insertItem(tableName, typeName, values) {
  const itemSet = {
    id: uuidv4(),
    startAt: groupStartTime,
    finishAt: 0,
    lockedUntil: 0,
    // set default Amplify fields - specifying manually to avoid call going over GraphQL API
    createdAt: groupStartTimeIso,
    updatedAt: groupStartTimeIso,
    _version: 1,
    _lastChangedAt: 0,
    __typename: typeName,
    ...values
  };
  const putParams = {
    TableName: tableName,
    Item: itemSet
  };
  docClient.put(putParams, (err) => {
    if (err) {
      console.log(`Failed to create new URL entry: ${JSON.stringify(err, null, 2)}`);
    }
  });
}

function processUrl(item) {
  const newUri = replaceVariables(item.uri);
  insertItem(process.env.API_STATUSTUTUKACLOUD_CHECKURLRUNSTABLE_NAME, 'CheckUrlRuns', {
    fullUri: newUri,
    checkUrlID: item.id
  });
}

function processQuota(item) {
  const newUri = `/index.cfm/clients/${item.clientId}/quota_balance`;
  insertItem(process.env.API_STATUSTUTUKACLOUD_QUOTARUNSTABLE_NAME, 'QuotaRuns', {
    apiEndpoint: newUri,
    balanceLimit: item.balanceLimit,
    quotaID: item.id
  });
}

function processQuotaItem(groupId) {
  const itemsParams = {
    TableName: process.env.API_STATUSTUTUKACLOUD_QUOTASTABLE_NAME,
    IndexName: 'bySchedule',
    KeyConditionExpression: 'scheduleID = :groupId',
    FilterExpression: '#dltd <> :bTrue',
    ExpressionAttributeNames: {
      '#dltd': '_deleted'
    },
    ExpressionAttributeValues: {
      ':groupId': groupId,
      ':bTrue': true
    }
  };
  docClient.query(itemsParams, (err, data) => {
    if (err) {
      console.log(`Unable to query group items table: ${JSON.stringify(err, null, 2)}`);
    } else {
      data.Items.forEach(processQuota);
    }
  });
}

function processGroupItem(groupId) {
  const itemsParams = {
    TableName: process.env.API_STATUSTUTUKACLOUD_CHECKURLSTABLE_NAME,
    IndexName: 'bySchedule',
    KeyConditionExpression: 'scheduleID = :groupId',
    FilterExpression: '#dltd <> :bTrue',
    ExpressionAttributeNames: {
      '#dltd': '_deleted'
    },
    ExpressionAttributeValues: {
      ':groupId': groupId,
      ':bTrue': true
    }
  };
  docClient.query(itemsParams, (err, data) => {
    if (err) {
      console.log(`Unable to query group items table: ${JSON.stringify(err, null, 2)}`);
    } else {
      data.Items.forEach(processUrl);
    }
  });
}

function processGroup(group) {
  const expression = cronParser.parseExpression(group.frequency);
  const nextRun = expression.next();
  if (queryWindow[0] <= nextRun.getTime() && queryWindow[1] >= nextRun.getTime()) {
    console.log(`Running group "${group.name}" for schedule ${nextRun.toString()}`);
    processGroupItem(group.id);
    processQuotaItem(group.id);
  }
}

exports.handler = (event, context, callback) => {
  docClient.scan(groupParams, (err, data) => {
    if (err) {
      console.log(`Unable to query groups table: ${JSON.stringify(err, null, 2)}`);
      callback(err);
    } else {
      data.Items.forEach(processGroup);
      callback(null, 'Processed');
    }
  });
};
